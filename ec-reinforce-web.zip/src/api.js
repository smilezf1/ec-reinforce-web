const baseUrl = "http://192.168.3.58:9990/manxi-reinforce";
export default {
    baseUrl
}