<template>
  <div class="reinforceItem">
    <div class="reinforceItemHeader">
      <p>当前位置: 加固项</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "reinforceItem"
};
</script>
<style>
.reinforceItemHeader {
  height: 50px;
  line-height: 50px;
  padding-left: 20px;
  font-size: 14px;
}
</style>
