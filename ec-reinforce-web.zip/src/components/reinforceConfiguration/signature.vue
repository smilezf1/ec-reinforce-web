<template>
  <div class="signature">
    <div class="signatureHeader">
      <p>当前位置: 签名服务</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "signature"
};
</script>
<style>
.signatureHeader {
  height: 50px;
  line-height: 50px;
  padding-left: 20px;
  font-size: 14px;
}
</style>
