<template>
  <div class="reinforceStrategy">
    <div class="reinforceStrategyHeader">
      <p>当前位置:加固策略</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "reinforceStrategy"
};
</script>
<style>
.reinforceStrategyHeader {
  height: 50px;
  line-height: 50px;
  padding-left: 20px;
  font-size: 14px;
}
</style>
