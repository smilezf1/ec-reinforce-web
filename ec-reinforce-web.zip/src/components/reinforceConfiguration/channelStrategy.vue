<template>
  <div class="channelStrategy">
    <div class="channelStrategyHeader">
      <p>当前位置:加固渠道</p>
    </div>
  </div>
</template>
<script>
export default {
  name: "channelStrategy"
};
</script>
<style>
.channelStrategyHeader {
  height: 50px;
  line-height: 50px;
  padding-left:20px;
  font-size:14px;
}
</style>
